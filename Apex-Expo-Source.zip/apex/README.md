# Apex

A minimal dark-themed Expo / React Native starter branded **Apex**.

## Run locally

```bash
npm install
npx expo start
```

Scan the QR code with Expo Go, or run on an iOS simulator with `npx expo start --ios`.

## Build an iOS IPA

An IPA requires Apple signing credentials and an Apple Developer account. From a Mac with Xcode, configure an EAS build or use Xcode's archive workflow. For EAS:

```bash
npx eas-cli build:configure
npx eas-cli build --platform ios --profile production
```

You will need to configure signing in your own Expo/Apple accounts. This repository contains source code, not a signed IPA.
