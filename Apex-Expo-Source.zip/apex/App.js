import React from 'react';
import { SafeAreaView, View, Text, StyleSheet, StatusBar, ScrollView } from 'react-native';

const features = [
  { number: '01', title: 'Your next level', detail: 'Small steps. Serious momentum.' },
  { number: '02', title: 'Stay in focus', detail: 'Make room for what matters.' },
  { number: '03', title: 'Keep your edge', detail: 'Progress, one day at a time.' },
];

export default function App() {
  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" />
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.topline}>
          <View style={styles.mark}><Text style={styles.markText}>A</Text></View>
          <Text style={styles.wordmark}>APEX</Text>
          <Text style={styles.edition}>01 / 26</Text>
        </View>
        <View style={styles.hero}>
          <Text style={styles.eyebrow}>BUILT FOR WHAT'S NEXT</Text>
          <Text style={styles.headline}>Find your{ '\n' }<Text style={styles.accent}>apex.</Text></Text>
          <Text style={styles.subhead}>A clearer way to move forward. Start with one intention, and build from there.</Text>
          <View style={styles.action}><Text style={styles.actionText}>LET'S BEGIN</Text><Text style={styles.arrow}>↗</Text></View>
        </View>
        <View style={styles.divider} />
        <Text style={styles.sectionLabel}>THE APEX PRINCIPLE</Text>
        {features.map((item) => (
          <View key={item.number} style={styles.row}>
            <Text style={styles.number}>{item.number}</Text>
            <View style={styles.rowCopy}><Text style={styles.rowTitle}>{item.title}</Text><Text style={styles.rowDetail}>{item.detail}</Text></View>
            <Text style={styles.rowArrow}>↗</Text>
          </View>
        ))}
        <Text style={styles.footer}>A LITTLE BETTER, EVERY DAY.</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#080B12' },
  container: { paddingHorizontal: 26, paddingTop: 18, paddingBottom: 36 },
  topline: { flexDirection: 'row', alignItems: 'center', height: 44 },
  mark: { width: 34, height: 34, borderRadius: 11, backgroundColor: '#C7F36B', alignItems: 'center', justifyContent: 'center' },
  markText: { color: '#080B12', fontWeight: '900', fontSize: 20, fontStyle: 'italic' },
  wordmark: { color: '#F4F5F2', fontSize: 14, letterSpacing: 4, fontWeight: '800', marginLeft: 11 },
  edition: { marginLeft: 'auto', color: '#7D8490', fontSize: 10, letterSpacing: 1.5 },
  hero: { paddingTop: 72, paddingBottom: 52 },
  eyebrow: { color: '#C7F36B', letterSpacing: 2.2, fontSize: 10, fontWeight: '700' },
  headline: { color: '#F4F5F2', fontSize: 62, lineHeight: 65, letterSpacing: -2.5, fontWeight: '800', marginTop: 18 },
  accent: { color: '#C7F36B', fontStyle: 'italic' },
  subhead: { color: '#9AA1AE', fontSize: 15, lineHeight: 24, marginTop: 20, maxWidth: 300 },
  action: { marginTop: 32, height: 54, borderRadius: 14, backgroundColor: '#C7F36B', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 18 },
  actionText: { color: '#11170B', fontSize: 11, letterSpacing: 1.8, fontWeight: '800' },
  arrow: { color: '#11170B', fontSize: 20 },
  divider: { height: 1, backgroundColor: '#252A34', marginBottom: 24 },
  sectionLabel: { color: '#757D89', fontSize: 10, letterSpacing: 1.8, fontWeight: '700', marginBottom: 9 },
  row: { minHeight: 76, flexDirection: 'row', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: '#20252E' },
  number: { color: '#C7F36B', width: 38, fontSize: 11, fontWeight: '700' },
  rowCopy: { flex: 1 },
  rowTitle: { color: '#F0F1EE', fontSize: 15, fontWeight: '600' },
  rowDetail: { color: '#858D99', fontSize: 12, marginTop: 5 },
  rowArrow: { color: '#7B8390', fontSize: 17 },
  footer: { color: '#59616D', fontSize: 9, letterSpacing: 2, marginTop: 30, textAlign: 'center' },
});
